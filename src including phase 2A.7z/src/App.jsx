import React from 'react';
import { AlertTriangle, CheckCircle, Info, Zap, Users, TrendingUp, Award } from 'lucide-react';
import Layout from '@/components/Layout';
import ErrorBoundary from '@/components/ErrorBoundary';
import ErrorToastContainer from '@/components/ErrorToastContainer';
import { ErrorProvider, useErrorHandler, ERROR_TYPES, ERROR_SEVERITY } from '@/hooks/useErrorHandler';
import { UAEButton } from '@/components/ui/uae-button';
import { UAECard, UAECardHeader, UAECardTitle, UAECardDescription, UAECardContent, UAECardFooter } from '@/components/ui/uae-card';
import { Button } from '@/components/ui/button';
import './App.css';

// Demo component to test error handling
const ErrorTestComponent = () => {
  const { handleError, withErrorHandling, ERROR_TYPES, ERROR_SEVERITY } = useErrorHandler();

  const triggerNetworkError = () => {
    const error = new Error('Failed to fetch user data from server');
    handleError(error, {
      type: ERROR_TYPES.NETWORK,
      severity: ERROR_SEVERITY.HIGH,
      context: 'User Profile Loading'
    });
  };

  const triggerValidationError = () => {
    const error = new Error('Email format is invalid');
    handleError(error, {
      type: ERROR_TYPES.VALIDATION,
      severity: ERROR_SEVERITY.MEDIUM,
      context: 'Profile Form Validation'
    });
  };

  const triggerCriticalError = () => {
    const error = new Error('Database connection lost');
    handleError(error, {
      type: ERROR_TYPES.SERVER,
      severity: ERROR_SEVERITY.CRITICAL,
      context: 'System Health Check'
    });
  };

  const triggerAsyncError = async () => {
    const result = await withErrorHandling(
      async () => {
        throw new Error('Async operation failed');
      },
      {
        errorOptions: {
          type: ERROR_TYPES.CLIENT,
          severity: ERROR_SEVERITY.LOW,
          context: 'Background Task'
        }
      }
    );
    
    if (!result.success) {
      console.log('Async operation failed gracefully');
    }
  };

  return (
    <UAECard variant="default" className="mb-6">
      <UAECardHeader>
        <UAECardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-uae-gold" />
          Error Handling Demo
        </UAECardTitle>
        <UAECardDescription>
          Test the enhanced error handling system with different error types and severities.
        </UAECardDescription>
      </UAECardHeader>
      <UAECardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <UAEButton onClick={triggerNetworkError} variant="outline" className="w-full">
            Network Error (High)
          </UAEButton>
          <UAEButton onClick={triggerValidationError} variant="outline" className="w-full">
            Validation Error (Medium)
          </UAEButton>
          <UAEButton onClick={triggerCriticalError} variant="outline" className="w-full">
            Critical Error
          </UAEButton>
          <UAEButton onClick={triggerAsyncError} variant="outline" className="w-full">
            Async Error (Low)
          </UAEButton>
        </div>
      </UAECardContent>
    </UAECard>
  );
};

// Dashboard component showcasing UAE design system
const Dashboard = () => {
  const stats = [
    {
      title: 'Active Applications',
      value: '12',
      change: '+3 this week',
      icon: TrendingUp,
      color: 'text-uae-green'
    },
    {
      title: 'Profile Views',
      value: '248',
      change: '+15% this month',
      icon: Users,
      color: 'text-uae-gold'
    },
    {
      title: 'Skills Verified',
      value: '8',
      change: '2 pending',
      icon: Award,
      color: 'text-uae-navy'
    },
    {
      title: 'AI Recommendations',
      value: '5',
      change: 'Updated today',
      icon: Zap,
      color: 'text-uae-green'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="gradient-uae-primary rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome back, Ahmed!</h1>
            <p className="text-white/90">
              You have 3 new opportunities matching your profile. Let's explore them together.
            </p>
          </div>
          <div className="hidden md:block">
            <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
              <Users className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>
        <div className="mt-6 flex gap-4">
          <UAEButton variant="secondary" className="bg-white text-uae-navy hover:bg-white/90">
            View Opportunities
          </UAEButton>
          <UAEButton variant="outline" className="border-white text-white hover:bg-white hover:text-uae-navy">
            Update Profile
          </UAEButton>
        </div>
      </div>

      {/* Error Testing Section */}
      <ErrorTestComponent />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <UAECard key={index} variant="default" className="hover-lift">
            <UAECardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold text-uae-navy">{stat.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{stat.change}</p>
                </div>
                <div className={`${stat.color}`}>
                  <stat.icon className="w-8 h-8" />
                </div>
              </div>
            </UAECardContent>
          </UAECard>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <UAECard variant="default">
          <UAECardHeader>
            <UAECardTitle>Recent Applications</UAECardTitle>
            <UAECardDescription>
              Track your latest job applications and their status.
            </UAECardDescription>
          </UAECardHeader>
          <UAECardContent>
            <div className="space-y-4">
              {[
                { company: 'Emirates Airlines', position: 'Software Engineer', status: 'Interview Scheduled', color: 'bg-uae-green' },
                { company: 'ADNOC', position: 'Data Analyst', status: 'Under Review', color: 'bg-uae-gold' },
                { company: 'Dubai Municipality', position: 'Project Manager', status: 'Application Sent', color: 'bg-uae-navy' }
              ].map((app, index) => (
                <div key={index} className="flex items-center gap-4 p-3 rounded-lg bg-muted/50">
                  <div className={`w-3 h-3 rounded-full ${app.color}`}></div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{app.position}</p>
                    <p className="text-xs text-muted-foreground">{app.company}</p>
                  </div>
                  <span className="text-xs px-2 py-1 bg-background rounded-full">
                    {app.status}
                  </span>
                </div>
              ))}
            </div>
          </UAECardContent>
          <UAECardFooter>
            <UAEButton variant="outline" className="w-full">
              View All Applications
            </UAEButton>
          </UAECardFooter>
        </UAECard>

        <UAECard variant="default">
          <UAECardHeader>
            <UAECardTitle>AI Recommendations</UAECardTitle>
            <UAECardDescription>
              Personalized career opportunities based on your profile.
            </UAECardDescription>
          </UAECardHeader>
          <UAECardContent>
            <div className="space-y-4">
              {[
                { title: 'Senior Developer Role', match: '95%', company: 'Technology Innovation Institute' },
                { title: 'Product Manager', match: '88%', company: 'Careem' },
                { title: 'UX Designer', match: '82%', company: 'Noon' }
              ].map((rec, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div>
                    <p className="font-medium text-sm">{rec.title}</p>
                    <p className="text-xs text-muted-foreground">{rec.company}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-medium text-uae-green">{rec.match}</span>
                    <p className="text-xs text-muted-foreground">match</p>
                  </div>
                </div>
              ))}
            </div>
          </UAECardContent>
          <UAECardFooter>
            <UAEButton variant="primary" className="w-full">
              Explore Recommendations
            </UAEButton>
          </UAECardFooter>
        </UAECard>
      </div>

      {/* Design System Showcase */}
      <UAECard variant="featured">
        <UAECardHeader>
          <UAECardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-uae-green" />
            Phase 2A: Foundation Enhancement Complete
          </UAECardTitle>
          <UAECardDescription>
            Enhanced error handling system and UAE-inspired design system successfully implemented.
          </UAECardDescription>
        </UAECardHeader>
        <UAECardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 rounded-lg bg-uae-pearl">
              <AlertTriangle className="w-8 h-8 text-uae-gold mx-auto mb-2" />
              <h4 className="font-medium text-uae-navy">Error Boundaries</h4>
              <p className="text-xs text-muted-foreground">Graceful error handling</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-uae-pearl">
              <Info className="w-8 h-8 text-uae-navy mx-auto mb-2" />
              <h4 className="font-medium text-uae-navy">Toast Notifications</h4>
              <p className="text-xs text-muted-foreground">User-friendly messages</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-uae-pearl">
              <Award className="w-8 h-8 text-uae-green mx-auto mb-2" />
              <h4 className="font-medium text-uae-navy">UAE Design System</h4>
              <p className="text-xs text-muted-foreground">Cultural design elements</p>
            </div>
          </div>
        </UAECardContent>
        <UAECardFooter className="justify-between">
          <div className="text-sm text-muted-foreground">
            Ready for Phase 2B: UI/UX Enhancement
          </div>
          <UAEButton variant="success">
            Continue to Phase 2B
          </UAEButton>
        </UAECardFooter>
      </UAECard>
    </div>
  );
};

// Main App component
function App() {
  return (
    <ErrorProvider>
      <ErrorBoundary>
        <Layout>
          <Dashboard />
          <ErrorToastContainer />
        </Layout>
      </ErrorBoundary>
    </ErrorProvider>
  );
}

export default App;

