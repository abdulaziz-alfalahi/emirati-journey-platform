
export { default as EducationPathwayLayout } from './EducationPathwayLayout';
export type { 
  EducationPathwayLayoutProps, 
  StatItem, 
  TabItem
} from './EducationPathwayLayout';
