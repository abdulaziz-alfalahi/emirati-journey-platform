
// This file would typically contain types, but we're using the global types
// from src/types/summerCamps.ts. This file is just for organization.

export {}; // Empty export to make TypeScript recognize this as a module
