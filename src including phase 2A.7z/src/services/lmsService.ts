
// Re-export from the new modular service structure
export { lmsService } from './lms';

// This file is kept for backward compatibility
// Use imports from ./lms instead for new code
